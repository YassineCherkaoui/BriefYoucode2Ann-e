package com.gestion.employee.model;

public class Profils {
	private int id;
	private String code;
	private String libelle;
	private static int auto;
	
	//Getters
	public int getId() {
		return id;
	}
	public String getCode() {
		return code;
	}
	public String getLibelle() {
		return libelle;
	}
	public static int getAuto() {
		return auto;
	}
	//Setters
	public void setId(int id) {
		this.id = id;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}
	public static void setAuto(int auto) {
		Profils.auto = auto;
	}
	//Constructor
	public Profils(String code,String libelle) {
		this.id = ++auto;
		this.code = code;
		this.libelle = libelle;
	}
	//Displat ToString
	public String toString(){
		return this.code + "" + this.libelle;
	}
	




}
