package com.gestion.employee.app;
import com.gestion.employee.model.Profils;
import com.gestion.employee.model.Utilisateur;

public class Application {

	public static void main(String[] args) {
		//LES PROFILS
		Profils Profils[] = new Profils[5];
		Profils[0] = new Profils("Manager", "MN");
		Profils[1] = new Profils("Directeur g�n�ral", "DG");
		Profils[2] = new Profils("Chef de projet", "CP");
		Profils[3] = new Profils("Directeur de projet", "DP");
		Profils[4] = new Profils("Directeur des ressources humaines", "DRH");
		// Utilisateurs
		Utilisateur utili[] = new Utilisateur[6];
		// utilisateur [LOGIN]
		utili[0] = new Utilisateur("login","password","services","nom","prenom","email","telephone","address"
									, 25000 ,Profils[0]);
		utili[1] = new Utilisateur("admin","admin","services","yassine","cherkaoui","yassin@gmail.Com","06121212"
				, "Agadir" , 20000,Profils[1]);
		utili[2] = new Utilisateur("yassin2","cher2","yassine","agadir","06111111111","CP","yassine"
				, "yassine" , 15000,Profils[2]);
		utili[3] = new Utilisateur("yassin3","cher3","yassine","agadir","06111111111","DP","yassine"
				, "yassine" , 10000,Profils[3]);
		utili[4] = new Utilisateur("yassin4","cher4","yassine","agadir","06111111111","DRH","yassine"
				, "yassine" , 5000,Profils[4]);
		utili[5] = new Utilisateur("login","password","services","manager","manager","email","telephone","address"
				, 25050 ,Profils[0]);
		//Display list of utilisateur 
		System.out.println("___________________________________");
		System.out.println("liste of Utilisateur: ");
		for (Utilisateur ut : utili) {
			ut.display();
		}
		// Display list of Manager's
		System.out.println("___________________________________|");
		System.out.println("List of managers: ");
		for (Utilisateur ut : utili) {
			if (ut.getProfils().getLibelle().equals("MN")) {
				ut.display();
			}
		}
	}

}
