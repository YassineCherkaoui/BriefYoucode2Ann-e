package com.gestion.employee.model;

public class Utilisateur extends Personne{
	private String login;
	private String password;
	private String service;
	private Profils Profils;
	
	//Getters
	public String getLogin() {
		return login;
	}
	public String getPassword() {
		return password;
	}
	public String getService() {
		return service;
	}
	//Setters
	public void setLogin(String login) {
		this.login = login;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void setService(String service) {
		this.service = service;
	}
	
	public Utilisateur(String login,String password,String service,String nom,
							String prenom,String email,String telephone,String adresse,double salaire,Profils Profils) {
		super(nom,prenom,email,adresse,telephone,salaire);
		this.login = login;
		this.password = password;
		this.service = service;
		this.Profils = Profils;
	}
	//equalsIgnoreCase == true 
	//calcule de salaire
	public double CalculSalaire() {
		if (this.Profils.getLibelle().equalsIgnoreCase("Manager")) 
			return  8 * this.salaire;
			
			else if(this.Profils.getLibelle().equalsIgnoreCase("Directeur"))
				return 15 * this.salaire;
			return super.CalculSalaire();
	}
	//affichage
	public void display() {
		super.display();
		System.out.println(" and i'm a "+this.Profils.getLibelle() + " Your salary :" +this.CalculSalaire());
	}
	
	// get profile
	public Profils getProfils() {
		return Profils;
	}

	
}
