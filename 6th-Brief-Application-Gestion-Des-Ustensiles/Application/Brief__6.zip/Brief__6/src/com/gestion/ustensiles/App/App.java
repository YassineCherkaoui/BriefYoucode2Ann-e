package com.gestion.ustensiles.App;
import java.sql.SQLException;
import java.util.Scanner;
import com.gestion.ustensiles.sql.Configue;
import com.gestion.ustensiles.models.*;
public class App {

	public static void main(String[] args) throws SQLException {
		Scanner scan= new Scanner(System.in);
		Configue con = new Configue();
		con.Connect();
		
		AssietteRonde assietteronde = new AssietteRonde();
		AssietteCarree assiettecarree = new AssietteCarree();
		Cuill�re cuillere = new Cuill�re();
		
		int anne_de_fabrication =0;
		double rayon =0;
		double cote =0;
		double longueur =0;
		int id = 0;	 
		while (true) {
			System.out.println("__________Utensil Management___________|");
			System.out.println("ADD_________________________________[1]|");
			System.out.println("Show Spoons_________________________[2]|");
			System.out.println("Display Plates Surface______________[3]|");
			System.out.println("Show Total Value____________________[4]|");
			System.out.println("Edit Utensil________________________[5]|");
			System.out.print("Choice: --> ");
			String method=scan.next();
			switch(method) {
			 case "1":
				 System.out.println("Year of manufacture: ");
				 anne_de_fabrication = scan.nextInt();
				 System.out.println("______________________________________|");
				 System.out.println("Add Round Plate____________________[1]|");
				 System.out.println("Add PlateCarree____________________[2]|");
				 System.out.println("Spoon______________________________[3]|");
				 System.out.print("Choice: --> ");
				 String method2=scan.next();
				 switch(method2) {
				  case "1":
					  System.out.println("Round Plate shelf:____________________|");
					  rayon = scan.nextDouble();
					  assietteronde.create_data(rayon,anne_de_fabrication);
					  break;
				  case "2":
					  System.out.println("Rib of Square Plate:__________________|");
					  cote = scan.nextDouble();
					  assiettecarree.create_data(cote,anne_de_fabrication);
					  break;
				  case "3":
					  System.out.println("Spoon Length:_________________________|");
					  longueur = scan.nextDouble();
					  cuillere.create_data(longueur,anne_de_fabrication);
					  break;
					  default:
				 }
				 break;
			 case "2":
				 cuillere.DisplayCuilleres(2);
				 break;
			 case "3":
				 System.out.println("Total area Round Plate_____________[1]|");
				 System.out.println("Total area Square Plate____________[2]|");
				 System.out.print("Choice: --> ");
				 String method3=scan.next();
				 switch(method3) {
					 case "1":
						 //1
						 assietteronde.read_data();
						 break;
					 case "2":
						 assiettecarree.read_data();
						 break;
					 default:
				 }
				 break;
			 case "4":
				 System.out.println("Spoon______________________________[1]|");
				 System.out.println("Round plate________________________[2]|");
				 System.out.println("Square Plate_______________________[3]|");
				 System.out.print("Choice: --> ");
				 String method4=scan.next();
				 switch(method4) {
				 	case "1":
				 		cuillere.DisplayCuilleres(1);
				 		break;
				 	case "2":
				 		cuillere.DisplayCuilleres(2);
				 		break;
				 	case "3":
				 		cuillere.DisplayCuilleres(3);
				 		break;
				 	default:
				 }
				 break;
				 //Update
			 case "5":;
					 System.out.println("Update Spoon_______________________[1]|");
					 System.out.println("Update Round plate_________________[2]|");
					 System.out.println("UpdateSquare Plate_________________[3]|");
					 System.out.print("Choice: --> ");
					String method5=scan.next();
					switch(method5) {
						case "1":
							cuillere.read_data();
							 System.out.println("Update ID :___________________________|");
							id = scan.nextInt();
							 System.out.println("Update Length :_______________________|");
							longueur = scan.nextDouble();
							 System.out.println("Update Year of manufacture :__________|");
							anne_de_fabrication = scan.nextInt();
							cuillere.update_data(id, longueur, anne_de_fabrication);
							System.out.println("______________________________________|");
							break;
						case "2":
							assietteronde.read_data();
							System.out.println("Update ID :___________________________|");
							id = scan.nextInt();
							System.out.println("Update Ray :__________________________|");
							rayon = scan.nextDouble();
							System.out.println("Update Year of manufacture :__________|");
							anne_de_fabrication = scan.nextInt();
							assietteronde.update_data(id, rayon, anne_de_fabrication);
							break;
						case "3":
							assiettecarree.read_data();
							System.out.println("______________________________________|");
							System.out.println("Update ID :___________________________|");
							id = scan.nextInt();
							System.out.println("Update Side :_________________________|");
							rayon = scan.nextDouble();
							System.out.println("Update Year of manufacture :__________|");
							anne_de_fabrication = scan.nextInt();
							assiettecarree.update_data(id, cote, anne_de_fabrication);
							break;
						default:
					}
				 default:	 
			}
		
		}
	}
}
