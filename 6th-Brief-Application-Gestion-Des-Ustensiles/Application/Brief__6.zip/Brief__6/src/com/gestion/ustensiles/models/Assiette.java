package com.gestion.ustensiles.models;
import com.gestion.ustensiles.sql.Configue;

public class Assiette extends Ustensile {
	
	Configue con = new Configue();
	
	private int id;
	public Assiette(){}
	public Assiette(int Id){
		this.id = Id;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	
}
