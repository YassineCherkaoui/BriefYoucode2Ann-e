package Com.gestion.employee.Models;

public interface Arisque {
     int prime = 200;
}
