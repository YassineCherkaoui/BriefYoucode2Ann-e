package Com.gestion.employee.interfaces;

public interface employes_a_risque {
	int prime = 200;
}
